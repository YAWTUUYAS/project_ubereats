// Exemple : polling SSE ou helper AJAX
console.log("Frontend UberEats loaded");
